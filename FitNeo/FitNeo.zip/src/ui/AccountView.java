package ui;

public class AccountView {

}
