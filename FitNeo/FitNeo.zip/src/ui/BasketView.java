package ui;

import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.BorderLayout;

public class BasketView extends JPanel {

	/**
	 * Create the panel.
	 */
	public BasketView() {
		setLayout(new BorderLayout(0, 0));

	}
}
