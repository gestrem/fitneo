package ui;

public class ActivityView {

}
