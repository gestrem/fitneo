package ui;

public class ManageRoomView {

}
