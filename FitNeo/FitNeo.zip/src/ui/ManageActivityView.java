package ui;

public class ManageActivityView {

}
