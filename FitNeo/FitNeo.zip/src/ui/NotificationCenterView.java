package ui;

public class NotificationCenterView {

}
