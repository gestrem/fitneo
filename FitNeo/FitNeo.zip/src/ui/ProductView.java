package ui;

public class ProductView {

}
