package ui;

public class ManageCategoryView {

}
