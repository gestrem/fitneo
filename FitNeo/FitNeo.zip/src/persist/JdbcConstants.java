package persist;

public interface JdbcConstants {
	 static final String DBURL = "jdbc:mysql://fitneo.c9coxdomfgjj.us-west-2.rds.amazonaws.com:3306/FITNEO";

	 static final String DBUSER = "fitneoMaster";

	 static final String DBPASS = "fitneo34";
}
