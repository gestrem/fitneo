package persist;

import core.User;

public class UserXML extends User {

	@Override
	public void setUser(String login) {
		// TODO Auto-generated method stub
		
	}

}
