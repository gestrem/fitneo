package persist;

import core.User;

public class UserSerializable extends User {

	@Override
	public void setUser(String login) {
		// TODO Auto-generated method stub
		
	}

}
