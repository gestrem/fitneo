package persist;
/**
 * 
 * @author Florent
 * Interface qui nous sert a stocker les identifiants de connexion a la base de donnees
 */
public interface JdbcConstants {
	 static final String DBURL = "jdbc:mysql://fitneo.c9coxdomfgjj.us-west-2.rds.amazonaws.com:3306/FITNEO";

	 static final String DBUSER = "fitneoMaster";

	 static final String DBPASS = "fitneo34";
}
