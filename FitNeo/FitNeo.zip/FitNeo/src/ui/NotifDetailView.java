package ui;

public class NotifDetailView {

}
