package ui;

public class ManageEventView {

}
